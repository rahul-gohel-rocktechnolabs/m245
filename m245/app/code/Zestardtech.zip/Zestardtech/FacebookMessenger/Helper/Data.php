<?php
namespace Zestardtech\FacebookMessenger\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\Context;

class Data extends AbstractHelper
{
    const FACEBOOKMESSENGER_PATH = 'fbmessenger_settings/fb_module/';

    protected $scopeConfig;
    
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig
    ) {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfig;
    }
    public function getConfigValue($configPath)
    {
        return $this->scopeConfig->getValue($configPath, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    public function getFbEnable()
    {
        return $this->getConfigValue(self::FACEBOOKMESSENGER_PATH . 'is_active');
    }
    public function getFbColor()
    {
        return $this->getConfigValue(self::FACEBOOKMESSENGER_PATH . 'messenger_themecolor');
    }
    public function getLoginGreeting()
    {
        return $this->getConfigValue(self::FACEBOOKMESSENGER_PATH . 'login_greeting');
    }
    public function getLogoutGreeting()
    {
        return $this->getConfigValue(self::FACEBOOKMESSENGER_PATH . 'logout_greeting');
    }
    public function getFacebookPageid()
    {
        return $this->getConfigValue(self::FACEBOOKMESSENGER_PATH . 'facebook_pageid');
    }
    public function getIconDisplay()
    {
        return $this->getConfigValue(self::FACEBOOKMESSENGER_PATH . 'display_view');
    }
    public function getDesktopPostion()
    {
        return $this->getConfigValue(self::FACEBOOKMESSENGER_PATH . 'desktop_icon_position');
    }
    public function getMobilePostion()
    {
        return $this->getConfigValue(self::FACEBOOKMESSENGER_PATH . 'mobile_icon_position');
    }
    public function getDisplayOnPage()
    {
        return $this->getConfigValue(self::FACEBOOKMESSENGER_PATH . 'display_on_page');
    }
}
