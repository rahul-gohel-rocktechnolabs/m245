<?php
namespace Zestardtech\FacebookMessenger\Model\Config\Source;

class DesktopPosition implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'bottom-right', 'label' => __('Bottom-Right')],
            ['value' => 'bottom-left', 'label' => __('Bottom-Left')],
            ['value' => 'bottom-middle', 'label' => __('Bottom-Middle')],
            ['value' => 'top-right', 'label' => __('Top-Right')],
            ['value' => 'top-left', 'label' => __('Top-Left')],
            ['value' => 'top-middle', 'label' => __('Top-Middle')],
            ['value' => 'right-middle', 'label' => __('Right-Middle')],
            ['value' => 'left-middle', 'label' => __('Left-Middle')]
        ];
    }
}
