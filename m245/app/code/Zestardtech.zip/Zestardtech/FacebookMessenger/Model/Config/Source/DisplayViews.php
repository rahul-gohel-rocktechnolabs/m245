<?php
namespace Zestardtech\FacebookMessenger\Model\Config\Source;

class DisplayViews implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'Both', 'label' => __('Both')],
            ['value' => 'Desktop', 'label' => __('Desktop')],
            ['value' => 'Mobile', 'label' => __('Mobile')]
        ];
    }
}
