<?php
namespace Zestardtech\FacebookMessenger\Model\Config\Source;

class DisplayOnPage implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'all_page', 'label' => __('All Pages')],
            ['value' => 'cms_index_index', 'label' => __('Homepage')],
            ['value' => 'catalog_category_view', 'label' => __('All Category Page')],
            ['value' => 'catalog_product_view', 'label' => __('All Product Page')],
            ['value' => 'checkout_cart_index', 'label' => __('Cart Page')],
            ['value' => 'checkout_index_index', 'label' => __('Checkout Page')],
            ['value' => 'cms_page_view', 'label' => __('All CMS Page')],
            ['value' => 'customer_account_index', 'label' => __('Customer Page')]
        ];
    }
}
