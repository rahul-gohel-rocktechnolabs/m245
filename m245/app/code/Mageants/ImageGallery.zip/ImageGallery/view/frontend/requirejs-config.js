var config = {
	paths: {
	    	"justifiedGallery": "Mageants_ImageGallery/js/jquery.justifiedGallery.min",
	    	"magnificpopup"   : "Mageants_ImageGallery/js/jquery.magnific-popup.min"
	},
	 shim: {
              	'justifiedGallery': {
                    deps: ['jquery']
                },
                'magnificpopup': {
                    deps: ['jquery']
                },
        }
};
